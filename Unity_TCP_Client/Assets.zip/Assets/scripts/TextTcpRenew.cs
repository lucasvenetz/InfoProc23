using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class TextTcpRenew : MonoBehaviour
{
    public TcpClient1 tcpClient1;
    public TMP_Text text1;
    void Update()
    {
        text1.text = tcpClient1.Notice;
    }
}
