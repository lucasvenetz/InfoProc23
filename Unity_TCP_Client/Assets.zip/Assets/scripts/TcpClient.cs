using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Text.RegularExpressions;

using UnityEngine;
using UnityEngine.UI;

using TMPro;

public class TcpClient1 : MonoBehaviour
{

    public bool isControlled;
    const string Uppers= "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    // 
    public TMP_InputField ipInputField1;
    public TMP_InputField portInputField;
    public TMP_InputField ipInputField2;
    public Button connectButton1;
    public Button connectButton2;

    public bool isUpdatePosition;

    public Vector3[] positionCache = new Vector3[2];

    public string Ip;
    public string Ip2;
    public int portNo;

    public int playerID = 324;
    public int[] KeysE = new int[7];
    public string Notice;

    [System.Serializable]
    public class PlayerPositionData
    {
        public string playerId1;
        public string playerId2;
        public float playerHealth1;
        public float playerHealth2;
        public float playerEnergy1;
        public float playerEnergy2;
        public Vector3 position1;
        public Vector3 position2;
    }

    [System.Serializable]
    private class Wrapper
    {
        public PlayerPositionData playerPositions;
    }

    private TcpClient client;
    private NetworkStream stream;
    private TcpClient client2;
    private NetworkStream stream2;
    private Thread receiveThread;
    private Thread serverThread; // connecting to python
    private TcpListener listener;
    public Vector3[] PlayerXTransformPosition = new Vector3[2];

    public string message1;

    private bool[] isKeyS = new bool[7];
    private bool[] isKeySUp = new bool[7];
    private bool[] isKeySDown = new bool[7];

    private bool isSend;
    public bool isStart;
    public int[] KeyS = new int[7];
    public int[] KeySInControlCache = new int[7];
    private string clientId;

    public float[] playerHealthData = new float[4];

    void Start()
    {
        isStart = false;
        isControlled = false;
        connectButton1.onClick.AddListener(OnConnectButtonClicked1);
        connectButton2.onClick.AddListener(OnConnectButtonClicked2);
    }

    private void OnConnectButtonClicked1()
    {
        Ip = ipInputField1.text;

        if (Ip == ""){
            Ip = "127.0.0.1";
        }

        string S1 = "";
        int charAmount = UnityEngine.Random.Range(5, 10); 
        for(int i=0; i<charAmount; i++)
        {
            S1 += Uppers[UnityEngine.Random.Range(0, Uppers.Length)];
        }

        
        clientId = "Player"+S1;

        Debug.Log("<> Start Connecting to Server");
        Debug.Log("<> ServerIP: " + Ip + "; Port: 5000");

        ConnectToServer();
    }

    private void OnConnectButtonClicked2()
    {
        string port = portInputField.text;
        //Ip2 = ipInputField2.text;
        portNo = 12345;
        /*
        if (Ip2 == ""){
            Ip2 = "127.0.0.1";
        }*/
        if (port != ""){
            portNo = int.Parse(portInputField.text);
        }

        listener = new TcpListener(IPAddress.Any, portNo);
        listener.Start();
        Debug.Log("<> Server started...");
        UpdateStatus("Server started ... ");

        // a subroutine from unity main
        serverThread = new Thread(new ThreadStart(HandleClient));
        serverThread.IsBackground = true; 
        serverThread.Start();
    }

    private void HandleClient()
    {
        TcpClient PyClient = listener.AcceptTcpClient();
        Debug.Log("<> Python Client connected!");
        UpdateStatus("Connected");
        NetworkStream stream = PyClient.GetStream();
        byte[] buffer = new byte[1024];
        int bytesRead;

        try
        {
            while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) != 0)
            {
                isControlled = true;
                Debug.Log("<> Controlled by FPGA: "+isControlled);
                string data = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                Debug.Log("<> Python sent data: "+data);

                Dictionary<string, string> result = new Dictionary<string, string>();

                string pattern = @"<([^>]+)>([^<]+)</\1>";
                Regex regex = new Regex(pattern);

                MatchCollection matches = regex.Matches(data);
                foreach (Match match in matches)
                {
                    if (match.Groups.Count == 3)
                    {
                        string key = match.Groups[1].Value;
                        string value = match.Groups[2].Value;
                        Debug.Log("<> (Py) Key: "+key+", Content: "+value);

                        if (key == "Key"){
                            string pattern2 = @"\d+";
                            MatchCollection matches2 = Regex.Matches(value, pattern2);
                            //Debug.Log(("Received action from server: ", value));
                            for (int i = 0; i < matches2.Count; i++)
                            {
                                if (int.TryParse(matches2[i].Value, out int number))
                                {
                                    KeyS[i] = number;
                                }
                            }
                            Debug.Log("<> (Regex) Key: "+key+", Content: "+KeyS);
                        }
                    }
                }
            }
        }
        catch (Exception e)
        {
            Debug.LogError("<> Python Client handling error: " + e.Message);
        }
        finally
        {
            PyClient.Close();
            Debug.Log("<> Python Client disconnected.");
        }
    }

    public void ConnectToServer()
    {
        try
        {
            client = new TcpClient(Ip, 5000);
            stream = client.GetStream();

            byte[] idData = Encoding.UTF8.GetBytes(clientId);
            stream.Write(idData, 0, idData.Length);
            Debug.Log("<> Sent ID to server: " + clientId);

            UpdateStatus("Waiting another player");

            // subroutine receiving server data
            receiveThread = new Thread(new ThreadStart(ReceiveData));
            receiveThread.IsBackground = true;
            receiveThread.Start();
        }
        catch (Exception e)
        {
            Debug.LogError("<> Client error: " + e.Message);
            UpdateStatus("Connection failed");
        }
    }

    void ParseData(string data, int playerID, int playerID2)
    {
        Dictionary<string, string> result = new Dictionary<string, string>();

        string pattern = @"<([^>]+)>([^<]+)</\1>";
        Regex regex = new Regex(pattern);

        MatchCollection matches = regex.Matches(data);
        foreach (Match match in matches)
        {
            if (match.Groups.Count == 3)
            {
                string key = match.Groups[1].Value;
                string value = match.Groups[2].Value;
                Debug.Log("<> Key: "+key+", Content: "+value);
                ReadParsedData(key, value, playerID, playerID2);
            }
        }
    }

    void ReadParsedData(string key, string value, int playerID, int playerID2){
        if (key == "STT")
        {
            //Debug.Log("STT");
        }
        else if (key == "POS")
        {
            Wrapper wrapper = JsonUtility.FromJson<Wrapper>(value);
            PlayerPositionData playerPositions = wrapper.playerPositions;
            //Debug.Log(("Received position from server: ", playerPositions));
            PlayerXTransformPosition[playerID] = playerPositions.position1;
            PlayerXTransformPosition[playerID2] = playerPositions.position2;
            playerHealthData[playerID] = playerPositions.playerHealth1; 
            playerHealthData[playerID2] = playerPositions.playerHealth2;
            playerHealthData[playerID+2] = playerPositions.playerEnergy1;
            playerHealthData[playerID2+2] = playerPositions.playerEnergy2;
        }
        else if (key == "ACT")
        {
            string pattern = @"\d+";
            MatchCollection matches = Regex.Matches(value, pattern);
            //Debug.Log(("Received action from server: ", value));
            for (int i = 0; i < matches.Count; i++)
            {
                if (int.TryParse(matches[i].Value, out int number))
                {
                    KeysE[i] = number;
                }
            }
        }
    }

    private void ReceiveData()
    {
        byte[] buffer = new byte[1024];
        int bytesRead;
        int playerID2 = 0;

        try
        {
            while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) != 0)
            {
                string jsonData = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                if (playerID > 10)
                {
                    Debug.Log(jsonData);
                    jsonData = ""+ jsonData[0];
                    playerID = int.Parse(jsonData);
                    Debug.Log("<> Assigned Player ID: " + playerID);
                    UpdateStatus("Your ID: " + playerID);

                    string shake = string.Format("SHK: {0}", playerID);

                    byte[] idData = Encoding.UTF8.GetBytes(shake);
                    stream.Write(idData, 0, idData.Length);
                    Debug.Log("<> Sent SHK to server: " + playerID);

                    if(playerID == 0){
                        playerID2 = 1;
                    }
                    if(playerID == 1){
                        playerID2 = 0;
                    }
                }
                else
                {
                    isStart = true;
                    ParseData(jsonData, playerID, playerID2);
                }
            }
            
        }
        catch (Exception e)
        {
            Debug.LogError("<> Receive data error: " + e.Message);
        }
    }

    void Update()
    {
        isSend = false;

        if (positionCache[0] != PlayerXTransformPosition[0] || positionCache[1] != PlayerXTransformPosition[1]){
            isUpdatePosition = true;
        }
        else{
            isUpdatePosition = false;
        }

        positionCache[0] = PlayerXTransformPosition[0];
        positionCache[1] = PlayerXTransformPosition[1];

        if (!isStart){
            for (int i = 0; i < 4; i++){
                playerHealthData[i] = 100f;
            }
        }

        if (isStart){
            if (!isControlled){
                message1 = "";

                isKeyS[0] = Input.GetKey(KeyCode.W);
                isKeyS[1] = Input.GetKey(KeyCode.A);
                isKeyS[2] = Input.GetKey(KeyCode.S);
                isKeyS[3] = Input.GetKey(KeyCode.D);
                isKeyS[4] = Input.GetKey(KeyCode.E);
                isKeyS[5] = Input.GetKey(KeyCode.R);
                isKeyS[6] = Input.GetMouseButton(0);

                isKeySDown[0] = Input.GetKeyDown(KeyCode.W);
                isKeySDown[1] = Input.GetKeyDown(KeyCode.A);
                isKeySDown[2] = Input.GetKeyDown(KeyCode.S);
                isKeySDown[3] = Input.GetKeyDown(KeyCode.D);
                isKeySDown[4] = Input.GetKeyDown(KeyCode.E);
                isKeySDown[5] = Input.GetKeyDown(KeyCode.R);
                isKeySDown[6] = Input.GetMouseButtonDown(0);

                isKeySUp[0] = Input.GetKeyUp(KeyCode.W);
                isKeySUp[1] = Input.GetKeyUp(KeyCode.A);
                isKeySUp[2] = Input.GetKeyUp(KeyCode.S);
                isKeySUp[3] = Input.GetKeyUp(KeyCode.D);
                isKeySUp[4] = Input.GetKeyUp(KeyCode.E);
                isKeySUp[5] = Input.GetKeyUp(KeyCode.R);
                isKeySUp[6] = Input.GetMouseButtonUp(0);

                isSend = false;
                message1 = clientId + ": ";

                for (int i = 0; i < 7; i++){
                    if(isKeySDown[i]){
                        KeyS[i] = 1;
                        isSend = true;
                    }
                    else if (isKeySUp[i]){
                        KeyS[i] = 0;
                        isSend = true;
                    }
                    string keystring = string.Format("{0}/", KeyS[i]);
                    message1 += keystring;
                }
            }

            if (isControlled){
                message1 = "";
                isSend = false;
                for (int i = 0; i < 7; i++){
                    if (KeyS[i] != KeySInControlCache[i]){
                        isSend = true;
                    }
                    KeySInControlCache[i] = KeyS[i];
                    Debug.Log("<> Change Key: " + (i+1) + "Value" + KeyS[i]);
                }
                if (isSend){
                    for (int i = 0; i < 7; i++){
                        message1 += string.Format("{0}/", KeyS[i]);
                    }
                    Debug.Log("<> Will Sent data to server: " + message1);
                }
            }
            
            if (isSend){
                SendDataToServer(message1);
                isSend = false;
            }
        }
    }

    private void SendDataToServer(string message)
    {
        try
        {
            byte[] data = Encoding.UTF8.GetBytes("<ACT>"+message+"</ACT>");
            stream.Write(data, 0, data.Length);
            Debug.Log("<> Sent data to server: " + message);
        }
        catch (Exception e)
        {
            Debug.LogError("<> Send data error: " + e.Message);
        }
    }

    private void UpdateStatus(string message)
    {
        Notice = message;
    }

    void OnDestroy()
    {
        if (client != null)
        {
            client.Close();
        }

        if (receiveThread != null && receiveThread.IsAlive)
        {
            receiveThread.Abort(); // 停止接收线程
        }
    }
}

/*using System;
using System.Net.Sockets;
using System.Text;
using UnityEngine;

class TcpSClient : MonoBehaviour
{
    private bool[] isKeyS = new bool[7];
    private bool[] isKeySUp = new bool[7];
    private bool[] isKeySDown = new bool[7];
    public string PlayerID;

    private bool isSend;
    public int[] KeyS = new int[7];
    public int[] EnemyKeyS = new int[7];
    public string[] KeyCodes = new string[7];
    private string message;


    void Start(){
        message = "start connection";
        Connect();
    }

    void Update()
    {
        message = "_";

        isKeyS[0] = Input.GetKey(KeyCode.W);
        isKeyS[1] = Input.GetKey(KeyCode.A);
        isKeyS[2] = Input.GetKey(KeyCode.S);
        isKeyS[3] = Input.GetKey(KeyCode.D);
        isKeyS[4] = Input.GetKey(KeyCode.E);
        isKeyS[5] = Input.GetKey(KeyCode.R);
        isKeyS[6] = Input.GetMouseButton(0);

        isKeySDown[0] = Input.GetKeyDown(KeyCode.W);
        isKeySDown[1] = Input.GetKeyDown(KeyCode.A);
        isKeySDown[2] = Input.GetKeyDown(KeyCode.S);
        isKeySDown[3] = Input.GetKeyDown(KeyCode.D);
        isKeySDown[4] = Input.GetKeyDown(KeyCode.E);
        isKeySDown[5] = Input.GetKeyDown(KeyCode.R);
        isKeySDown[6] = Input.GetMouseButtonDown(0);

        isKeySUp[0] = Input.GetKeyUp(KeyCode.W);
        isKeySUp[1] = Input.GetKeyUp(KeyCode.A);
        isKeySUp[2] = Input.GetKeyUp(KeyCode.S);
        isKeySUp[3] = Input.GetKeyUp(KeyCode.D);
        isKeySUp[4] = Input.GetKeyUp(KeyCode.E);
        isKeySUp[5] = Input.GetKeyUp(KeyCode.R);
        isKeySUp[6] = Input.GetMouseButtonUp(0);

        message = PlayerID + ": ";
        isSend = false;

        for (int i = 0; i < 7; i++){
            if(isKeySDown[i]){
                KeyS[i] = 1;
                isSend = true;
            }
            else if (isKeySUp[i]){
                KeyS[i] = 0;
                isSend = true;
            }
            string keystring = string.Format("{0}/", KeyS[i]);
            message += keystring;
        }

        if (isSend){
            Connect();
        }
    }

    public void Connect()
    {
        TcpClient client = new TcpClient("127.0.0.1", 5000);
        NetworkStream stream = client.GetStream();

        byte[] data = Encoding.UTF8.GetBytes(message);
        stream.Write(data, 0, data.Length);
        Console.WriteLine("Sent: " + message);

        byte[] buffer = new byte[1024];
        int bytesRead = stream.Read(buffer, 0, buffer.Length);
        string response = Encoding.UTF8.GetString(buffer, 0, bytesRead);
        Console.WriteLine("Received: " + response);

        client.Close();
    }
}
*/