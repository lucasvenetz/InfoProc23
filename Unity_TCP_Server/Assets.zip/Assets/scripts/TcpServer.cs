using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using UnityEngine;
using System.Text.RegularExpressions;
using TMPro;

public class TcpServer : MonoBehaviour
{
    public float sendInterval;
    private float timer = 0f;

    public bool p1A = false;
    public bool p2A = false;

    [System.Serializable]
    public class PlayerPositionData
    {
        public string playerId1;
        public string playerId2;
        public float playerHealth1;
        public float playerHealth2;
        public float playerEnergy1;
        public float playerEnergy2;
        public Vector3 position1;
        public Vector3 position2;
    }

    [System.Serializable]
    private class Wrapper
    {
        public PlayerPositionData playerPositions;
    }


    private TcpListener listener;
    private Thread serverThread;
    private Dictionary<TcpClient, string> clients = new Dictionary<TcpClient, string>(); // 存储客户端ID和对应的TcpClient
    private Dictionary<TcpClient, int> clientNumbers = new Dictionary<TcpClient, int>();
    public int[] reflection = new int[2];
    public GameObject[] PlayerX; 
    public Health[] health;
    public bool isStart;

    public int[] Keys1 = new int[7];
    public int[] Keys2 = new int[7];

    void Start()
    {
        StartServer();
    }

    public void StartServer()
    {
        listener = new TcpListener(IPAddress.Any, 5000);
        listener.Start();
        Debug.Log("Server started...");

        // a subroutine from unity main
        serverThread = new Thread(new ThreadStart(HandleClients));
        serverThread.IsBackground = true; 
        serverThread.Start();
    }

    private void HandleClients()
    {
        while (true)
        {
            try
            {
                TcpClient client = listener.AcceptTcpClient();
                Debug.Log("Client connected!");

                // a subroutine for client
                Thread clientThread = new Thread(new ParameterizedThreadStart(HandleClient));
                clientThread.IsBackground = true;
                clientThread.Start(client);
            }
            catch (Exception e)
            {
                Debug.LogError("Server error: " + e.Message);
                break;
            }
        }
    }

    private void AssignPlayerIds()
    {
        int playerId = 0;
        foreach (var pair in clients)
        {
            TcpClient client = pair.Key;
            clientNumbers[client] = playerId;
            reflection[playerId] = playerId;
            NetworkStream stream1 = client.GetStream();

            string playerIdMessage = playerId.ToString();
            byte[] data = Encoding.UTF8.GetBytes(playerIdMessage);
            stream1.Write(data, 0, data.Length);
            Debug.Log("Assigned Player ID: " + playerId + " to " + pair.Value + ", ClientInteral ID: " + client);

            playerId++;
        }
    }

    private void HandleClient(object obj)
    {
        TcpClient client = (TcpClient)obj;
        NetworkStream stream = client.GetStream();
        byte[] buffer = new byte[1024];
        int bytesRead;

        try
        {
            bytesRead = stream.Read(buffer, 0, buffer.Length);
            string clientId = Encoding.UTF8.GetString(buffer, 0, bytesRead);
            Debug.Log("Client ID received: " + clientId);

            lock (clients) // ensure safety
            {
                clients[client] = clientId;
            }

            if (clients.Count == 2)
            {
                AssignPlayerIds();
            }

            while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) != 0)
            {
                string data = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                if (isStart == false){
                    if (data.StartsWith("SHK: ")){
                        if (data[5] == '0'){
                            p1A = true;
                        }
                        if (data[5] == '1'){
                            p2A = true;
                        }
                    }
                    if (p1A && p2A){
                        Debug.Log("Game started!");
                        isStart = true;

                        byte[] data3 = Encoding.UTF8.GetBytes("<STT>STT<STT>");
                        stream.Write(data3, 0, data3.Length);
                        Debug.Log("STT");
                    }
                }
                

                Debug.Log("Received from Player" + clientNumbers[client]  + ": " + data);

                string sentToOpponent = data;

                string pattern = @"\d+";
                MatchCollection matches = Regex.Matches(data, pattern);

                if (clientNumbers[client] == 0){
                    for (int i = 0; i < matches.Count && i < 7; i++)
                    {
                        if (int.TryParse(matches[i].Value, out int number))
                        {
                            Keys1[i] = number;
                        }
                    }

                    TcpClient client2 = client;

                    foreach (var pair in clients)
                    {
                        if (clientNumbers[pair.Key] == 1) client2 = pair.Key;
                    }

                    lock (client2)
                    {
                        try
                        {
                            NetworkStream stream2 = client2.GetStream();
                            sentToOpponent = "<ACT>" + sentToOpponent + "</ACT>";
                            byte[] data2 = Encoding.UTF8.GetBytes(sentToOpponent);
                            stream2.Write(data2, 0, data2.Length);
                            Debug.Log("Sent position to " + client2 + " opponent action: " + sentToOpponent);
                        }
                        catch (Exception e)
                        {
                            Debug.LogError("Error sending data to " + client2 + ": " + e.Message);
                        }
                    }
                }

                else if (clientNumbers[client] == 1){
                    for (int i = 0; i < matches.Count && i < 7; i++)
                    {
                        if (int.TryParse(matches[i].Value, out int number))
                        {
                            Keys2[i] = number;
                        }
                    }

                    TcpClient client2 = client;

                    foreach (var pair in clients)
                    {
                        if (clientNumbers[pair.Key] == 0) client2 = pair.Key;
                    }

                    lock (client2)
                    {
                        try
                        {
                            NetworkStream stream2 = client2.GetStream();
                            sentToOpponent = "<ACT>" + sentToOpponent + "</ACT>";
                            byte[] data2 = Encoding.UTF8.GetBytes(sentToOpponent);
                            stream2.Write(data2, 0, data2.Length);
                            Debug.Log("Sent position to " + client2 + " opponent action: " + sentToOpponent);
                        }
                        catch (Exception e)
                        {
                            Debug.LogError("Error sending data to " + client2 + ": " + e.Message);
                        }
                    }
                }     
            }
        }
        catch (Exception e)
        {
            Debug.LogError("Client handling error: " + e.Message);
        }
        finally
        {
            lock (clients)
            {
                clients.Remove(client);
            }
            client.Close();
            Debug.Log("Client disconnected.");
        }
    }

    void Update()
    {
        timer += Time.deltaTime;

        if (timer >= sendInterval){

            timer = 0f;

            if (isStart){
                PlayerPositionData playerPositions = new PlayerPositionData { 
                    playerId1 = "Client1", 
                    playerId2 = "Client2", 
                    playerHealth1 = health[0].currentHealth,
                    playerHealth2 = health[1].currentHealth,
                    playerEnergy1 = health[0].currentEnergy,
                    playerEnergy2 = health[1].currentEnergy,
                    position1 = PlayerX[0].transform.position,
                    position2 = PlayerX[1].transform.position,
                };

                lock (clients)
                {
                    foreach (var pair in clients)
                    {
                        TcpClient client = pair.Key;

                        try
                        {
                            NetworkStream stream = client.GetStream();
                            string jsonData = "<POS>";
                            jsonData += JsonUtility.ToJson(new Wrapper { playerPositions = playerPositions }) + "</POS>";
                            byte[] data = Encoding.UTF8.GetBytes(jsonData);
                            stream.Write(data, 0, data.Length);
                            Debug.Log("Sent position to " + client + ": " + jsonData);
                        }
                        catch (Exception e)
                        {
                            Debug.LogError("Error sending data to " + client + ": " + e.Message);
                        }
                    }
                }
            }
        }
    }

    void OnDestroy()
    {
        if (listener != null)
        {
            listener.Stop();
            Debug.Log("Server stopped.");
        }

        if (serverThread != null && serverThread.IsAlive)
        {
            serverThread.Abort();
        }

        lock (clients)
        {
            foreach (var client in clients.Keys)
            {
                client.Close();
            }
            clients.Clear();
        }
    }
}
/*
using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using UnityEngine;
using System.Text.RegularExpressions;

public class TcpServer : MonoBehaviour
{
    private TcpListener listener;
    private Thread serverThread;
    public int[] Keys1 = new int[7];
    public GameObject Player1;

    void Start()
    {
        StartServer();
    }

    public void StartServer()
    {
        listener = new TcpListener(IPAddress.Any, 5000);
        listener.Start();
        Debug.Log("Server started...");

        serverThread = new Thread(new ThreadStart(HandleClients));
        serverThread.IsBackground = true;
        serverThread.Start();
    }

    private void HandleClients()
    {
        while (true)
        {
            try
            {
                TcpClient client = listener.AcceptTcpClient();
                Debug.Log("Client connected!");
                Thread clientThread = new Thread(new ParameterizedThreadStart(HandleClient));
                clientThread.IsBackground = true;
                clientThread.Start(client);
            }
            catch (Exception e)
            {
                Debug.LogError("Server error: " + e.Message);
                break;
            }
        }
    }

    private void HandleClient(object obj)
    {
        TcpClient client = (TcpClient)obj;
        NetworkStream stream = client.GetStream();
        byte[] buffer = new byte[1024];
        int bytesRead;

        try
        {
            while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) != 0)
            {
                string data = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                Debug.Log("Received: " + data);

                string pattern = @"\d+";
                MatchCollection matches = Regex.Matches(data, pattern);

                for (int i = 0; i < matches.Count; i++)
                {
                    if (int.TryParse(matches[i].Value, out int number))
                    {
                        Keys1[i] = number;
                    }
                }

                string response = "Server response: " + data;
                byte[] responseData = Encoding.UTF8.GetBytes(response);
                stream.Write(responseData, 0, responseData.Length);
            }
        }
        catch (Exception e)
        {
            Debug.LogError("Client handling error: " + e.Message);
        }
        finally
        {
            client.Close();
        }
    }

    void OnDestroy()
    {
        if (listener != null)
        {
            listener.Stop();
            Debug.Log("Server stopped.");
        }

        if (serverThread != null && serverThread.IsAlive)
        {
            serverThread.Abort();
        }
    }
}

*/